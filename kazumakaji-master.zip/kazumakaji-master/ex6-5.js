var  who65　='world';
function sayhello65(){
    alert('Hello, ' + who65 +  +'!');
}

function taro65(){
    who65 = '太郎';
    //alert(who65 + 'が来た!')
}

function hanako65(){
    who65 = '花子';
    //alert(who65 + 'が来た!')
}
function  gakita(){
    //who650 = 'が来た';
    alert(who65 + 'が来た!');
}

