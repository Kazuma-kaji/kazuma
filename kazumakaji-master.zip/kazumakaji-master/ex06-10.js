function imgchange1() {
    document.getElementById('logo').src= './image/kuma.png';
}