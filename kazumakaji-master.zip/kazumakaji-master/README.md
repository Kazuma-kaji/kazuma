<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>Web開発の練習１</title>
</head>
<body>
<!--文字の大きさの練習-->
<h1>Hello World</h1>
  <h2>Hello World</h2>
  <h3>Hello World</h3>
  <ol>
      <li>ほげほげ</li>
      <li>ほにゃらら</li>
  </ol>
</body>
</html>
# web2020-1
情報学特講１
