function txtchange1(){
    document.getElementById("txt1").innerHTML = "ナンバーワン！";
}
