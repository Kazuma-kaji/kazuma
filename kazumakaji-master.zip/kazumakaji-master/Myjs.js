alert("Hello,kazuma!") 
/*alert(1+1);
alert(Math.sqrt(1+1));
alert(Math.sqrt(2));
alert((Math.sqrt(2))+(Math.sqrt(3)));
alert(1 / 0);
alert(0/0);
alert(2+3);
alert('2'+'3');
alert(Number('2')+Number('3'));
alert(('2')+ 3);
alert((Number('2'))+3);*/




