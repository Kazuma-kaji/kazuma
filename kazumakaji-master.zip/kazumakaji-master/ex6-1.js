function sayhello61(){
    alert("Hello,Function!");
}

function saygoodbye(){
    alert("Goodbye");
}