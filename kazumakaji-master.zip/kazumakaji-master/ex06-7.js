var who67 = 'world';
function sayhello67(){
    alert('Hello,' + who67 + '!' );
}
function someone(x){
    who67 = x;

}
function gakita2(who67){
    alert(x + 'が来た');
}