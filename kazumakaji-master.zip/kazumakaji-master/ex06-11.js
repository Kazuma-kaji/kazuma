//function ChangeImageAndBack() {
    //document.getElementById('img13').src= './image/kuma.png';
//}
//setTimeout("ChangeImageAndBack", 3000);

function imgchange2() {
    document.getElementById('change').src= './image/josai.png';
}

    //onclick=setTimeout("imgchange2()", 3000);