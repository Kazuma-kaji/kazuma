function sayhello() {
    alert('Hello, ' + document.getElementById('who68').innerHTML+ '!');
}
function taro() {
    document.getElementById('who68').innerHTML= '太郎';
}
function hanako() {
    document.getElementById('who68').innerHTML= '花子';
}